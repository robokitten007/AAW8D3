const Game = require("./src/game");

const game = new Game();
game.play();
